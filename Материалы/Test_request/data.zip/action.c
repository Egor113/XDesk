Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_cookie("_ym_visorc_93511=w; DOMAIN=yandex.ru");

	web_add_cookie("_ym_visorc_722818=b; DOMAIN=yandex.ru");

	web_add_cookie("yp=1591050255.szm.1:1920x1080:1920x962#1577874250.ygu.1; DOMAIN=yandex.ru");

	web_add_cookie("_ym_visorc_50377519=b; DOMAIN=yandex.ru");

	web_add_cookie("yc=1575541457.zen.cach%3A1575285850; DOMAIN=yandex.ru");

	web_add_cookie("yandex_gid=213; DOMAIN=yandex.ru");

	web_add_cookie("_ym_isad=2; DOMAIN=yandex.ru");

	web_add_cookie("font_loaded=YSv1; DOMAIN=yandex.ru");

	web_add_cookie("_ym_d=1575282252; DOMAIN=yandex.ru");

	web_add_cookie("yandexuid=3819863651563211408; DOMAIN=yandex.ru");

	web_add_cookie("mda=0; DOMAIN=yandex.ru");

	web_add_cookie("my=YwA=; DOMAIN=yandex.ru");

	web_add_cookie("_ym_uid=1563211448711670427; DOMAIN=yandex.ru");

	web_add_cookie("yabs-frequency=/4/0000000000000000/7MsmS9Wu8ELLi72OE267VN9mc3WWUl8zRPWu9m00/; DOMAIN=yandex.ru");

	web_add_cookie("i=4X0BF0W8L7y5NtZixGmYVeWA9K6w8K4WQ33w1uYH+29UQdp6Z5aPlTC6B8RFndXo6XlfhnfoUeJHHK1PPgV4y4djXm4=; DOMAIN=yandex.ru");

	web_add_cookie("_ym_wasSynced=%7B%22time%22%3A1575282252467%2C%22params%22%3A%7B%22eu%22%3A0%7D%2C%22bkParams%22%3A%7B%7D%7D; DOMAIN=yandex.ru");

	web_add_cookie("_ym_isad=2; DOMAIN=yastatic.net");

	web_add_cookie("_ym_d=1575282311; DOMAIN=yastatic.net");

	web_add_cookie("_ym_uid=1575282311204012854; DOMAIN=yastatic.net");

	web_add_cookie("_ym_wasSynced=%7B%22time%22%3A1575282310574%2C%22params%22%3A%7B%22eu%22%3A0%7D%2C%22bkParams%22%3A%7B%7D%7D; DOMAIN=yastatic.net");

	web_url("yandex.ru", 
		"URL=https://yandex.ru/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://yastatic.net/s3/home/fonts/ys/1/text-regular.woff", ENDITEM, 
		"Url=https://yastatic.net/s3/home/fonts/ys/1/text-bold.woff", ENDITEM, 
		"Url=https://yastatic.net/s3/home/fonts/ys/1/text-medium.woff", ENDITEM, 
		"Url=https://yastatic.net/s3/chat/1.19.0/widget_ya.js", ENDITEM, 
		"Url=https://yastatic.net/islands/_/nJL92_8XGrQ8WN7LePOnzmpHzd4.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/x/Q/xk8YidkhGjIGOrFm_dL5781YA.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/w/j/Vc1CjGtwp8oRwfxQXoRxviCW0.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/k/8/gsSjWTalZ0Zl-yefsGisz0YJA.svg", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-direct/1612413/VGFg4ggwknW4sm2noucx7w/x450", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-yapic/48449/hiW0ORdK4MGliSwlgHCqYQNNhSg-1/islands-200", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/y/4/Jy-b3BgSC_rSXwEgmmoYVtrdE.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/D/b/zli9j3mTRUHAiPwR5tcthvT64.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/u/C/TC-jqYYDgoX-c-KrkX5Fq0DQI.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/u/X/LNZVn-n5hS89WJBNhtktAUa6g.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/7/3/mThhP_rfNdsFX-xiAxPt6BWbk.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/L/W/yXlW4cwIhhqYEbKac9EFxDRvQ.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/I/D/GmxoaNBGBwZJQ_L6OxNu-vPTM.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/U/1/o7ckruVIskZcRWhFoDDc5rung.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/R/6/NrxzASAPi9QSmGS6qAwJt-XRA.svg", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/G/H/BDByox5vWCEUL4A8CFOCY-cvg.svg", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews-logo/135513/1002-1544074003449-square/logo-square", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews-logo/26056/1047-1478692902215-square/logo-square", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews-logo/50744/1014-1478692899971-square/logo-square", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews-logo/117671/1027-1530099491421-square/logo-square", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews-logo/117671/1689-1573819514737-square/logo-square", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews-logo/50744/1551-1563808847385-square/logo-square", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews-logo/26056/1116-1478692904205-square/logo-square", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews-logo/135513/1040-1478692902361-square/logo-square", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ynews-logo/26056/1048-1478692902313-square/logo-square", ENDITEM, 
		"Url=https://yastatic.net/s3/home-static/_/X/5/3HcUcIQG1gNFlwgvzPC8zJQjs.css", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ott/224348/2a0000016d72f1376f8c0ca68028502167a9/150x225", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ott/374297/2a0000016340d118bfbd2fe065d5b6082a3c/150x225", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ott/2419418/2a0000016df878214ffc0246493909497734/150x225", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ott/239697/2a000001656ce13eb573a0e9bda156756d83/150x225", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ott/239697/2a000001677315260fbbf69465f02999ab81/150x225", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ott/223007/2a00000161285932fdb86bf8bcd3fd26e505/150x225", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ott/224348/2a000001626d3bc31264f027a8fe614bd136/150x225", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ott/223007/2a0000016271917184194a61bfd177aaf493/150x225", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-ott/374297/2a00000162b0c467169b6a4a072431fb6aac/150x225", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-yapic/0/0-0/islands-middle", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-yapic/20706/enc-80fe377b14ff588b8441116910bbf0d1/islands-200", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-yapic/28439/xOEt7A5yEVwfAuTJaATa8r7bUY-1574394145/islands-200", ENDITEM, 
		"Url=https://yastatic.net/iconostasis/_/8lFaTHLDzmsEZz-5XaQg9iTWZGE.png", "Referer=", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-banana/26007/bvu4lp1sv0gdoqzda7hfrs_banana_20141031_logox2066/svg", ENDITEM, 
		"Url=https://yastatic.net/s3/zen-lib/2.225.3/morda-desktop/app.css", ENDITEM, 
		"Url=https://yastatic.net/react/16.8.4/react-with-dom.min.js", ENDITEM, 
		"Url=https://yastatic.net/s3/zen-lib/2.225.3/morda-desktop/app-external-react.legacy.ru.bundle.js", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen_doc/1904927/pub_5d95b9f8ec575b00afa30177_5d95ba3d78125e00b17c6067/smart_crop_516x290_card_white", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen_doc/1721884/4008183145267317212/smart_crop_516x290_card_white", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen_doc/1707183/pub_5d79e36f118d7f00ae30c0d6_5d79e39179c26e00ae5210b1/smart_crop_516x290_card_white", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen_doc/1586459/pub_5d96f4cd35ca3100b1868fa5_5d96f50d35ca3100b1868faa/smart_crop_540x405", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen_doc/1584893/pub_5de1293f0a451800b1745501_5de141af34808200b02ee23f/smart_crop_516x290_card_white", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen_doc/1716911/-1341163441396927141/smart_crop_540x405", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen_doc/1860621/256165046914788372/smart_crop_516x290_card_white", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen-logos/201842/c223da3f/xh", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen-logos/200214/2c1ba914/xh", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen-logos/212539/1abd5123/xh", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen-logos/200214/81d2ef74/xh", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen-logos/201842/41f4dc55/xh", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen-logos/200214/a9dcd3d4/xh", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen-logos/200214/d0a4497c/xh", ENDITEM, 
		"Url=https://avatars.mds.yandex.net/get-zen-logos/223306/210d3a4c/xh", ENDITEM, 
		"Url=https://zen.s3.yandex.net/onboarding-logos/cybersportru/208.png", ENDITEM, 
		"Url=https://zen.s3.yandex.net/onboarding-logos/rbc/208.png", ENDITEM, 
		"Url=/search/yandcache.js", ENDITEM, 
		"Url=https://yastatic.net/s3/web4static/_/X6TRFMMpKzugGRoTBcdPYGovtnU.js", ENDITEM, 
		"Url=https://yastatic.net/s3/web4static/_/kikhcb107KEIYqQLbJTMaHe7qb8.js", ENDITEM, 
		"Url=https://yastatic.net/s3/web4static/_/MYPO186nOwXosmVyE0g9Xm8obNw.js", ENDITEM, 
		"Url=https://yastatic.net/react/16.8.4/react-with-dom-and-polyfills.min.js", ENDITEM, 
		"Url=https://yastatic.net/s3/web4static/_/cmmv5ByveliklEGiDrfh64srLVc.js", ENDITEM, 
		LAST);

	web_custom_request("logo-square", 
		"URL=https://avatars.mds.yandex.net/get-ynews-logo/50744/1014-1478692899971-square/logo-square", 
		"Method=HEAD", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=", 
		"Snapshot=t2.inf", 
		LAST);

	web_custom_request("logo-square_2", 
		"URL=https://avatars.mds.yandex.net/get-ynews-logo/26056/1047-1478692902215-square/logo-square", 
		"Method=HEAD", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=", 
		"Snapshot=t3.inf", 
		LAST);

	web_custom_request("logo-square_3", 
		"URL=https://avatars.mds.yandex.net/get-ynews-logo/26056/1116-1478692904205-square/logo-square", 
		"Method=HEAD", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=", 
		"Snapshot=t4.inf", 
		LAST);

	web_custom_request("logo-square_4", 
		"URL=https://avatars.mds.yandex.net/get-ynews-logo/135513/1002-1544074003449-square/logo-square", 
		"Method=HEAD", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=", 
		"Snapshot=t5.inf", 
		LAST);

	web_custom_request("logo-square_5", 
		"URL=https://avatars.mds.yandex.net/get-ynews-logo/135513/1040-1478692902361-square/logo-square", 
		"Method=HEAD", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=", 
		"Snapshot=t6.inf", 
		LAST);

	web_custom_request("logo-square_6", 
		"URL=https://avatars.mds.yandex.net/get-ynews-logo/26056/1048-1478692902313-square/logo-square", 
		"Method=HEAD", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=", 
		"Snapshot=t7.inf", 
		LAST);

	web_custom_request("logo-square_7", 
		"URL=https://avatars.mds.yandex.net/get-ynews-logo/117671/1027-1530099491421-square/logo-square", 
		"Method=HEAD", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=", 
		"Snapshot=t8.inf", 
		LAST);

	web_custom_request("logo-square_8", 
		"URL=https://avatars.mds.yandex.net/get-ynews-logo/117671/1689-1573819514737-square/logo-square", 
		"Method=HEAD", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=", 
		"Snapshot=t9.inf", 
		LAST);

	web_custom_request("logo-square_9", 
		"URL=https://avatars.mds.yandex.net/get-ynews-logo/50744/1551-1563808847385-square/logo-square", 
		"Method=HEAD", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=", 
		"Snapshot=t10.inf", 
		LAST);

	web_custom_request("logo-square_10", 
		"URL=https://avatars.mds.yandex.net/get-ynews-logo/117671/1027-1530099491421-square/logo-square", 
		"Method=HEAD", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/jpeg", 
		"Referer=", 
		"Snapshot=t11.inf", 
		LAST);

	web_add_cookie("yabs-frequency=/4/0000000000000000/VF8zRPWu9nrji72OE23bLR1mc3WXXtroS9Wu87hoFMsOE2S0/; DOMAIN=yandex.ru");

	web_add_cookie("_ym_d=1575282403; DOMAIN=yandex.ru");

	web_custom_request("click", 
		"URL=https://yandex.ru/clck/click", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://yandex.ru/", 
		"Snapshot=t12.inf", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=/reqid=1575282401.30245.139705.388477/path=690.2096.207/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701=2095.2154,207=1253.22,-cdn="
		"unknown/cts=1575282403688/*\r\n/reqid=1575282401.30245.139705.388477/path=690.2096.207/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701="
		"2095.1428,207=1453.12,-cdn=unknown/cts=1575282403688/*\r\n/reqid=1575282401.30245.139705.388477/path=690.2096.207/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,"
		"143.2112=0,143.2119=0,1701=2095.2154,207=1480.02,-cdn=unknown/cts=1575282403689/*\r\n/reqid=1575282401.30245.139705.388477/path=690.2096.207/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,"
		"143.2129=1575282401666,143.2112=0,143.2119=0,1701=2095.1428,207=1480.02,-cdn=unknown/cts=1575282403689/*\r\n/reqid=1575282401.30245.139705.388477/path=690.2096.207/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20"
		"(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701=2418,207=1480.62,-cdn=unknown/cts=1575282403689/*\r\n/reqid=1575282401.30245.139705.388477/path=690.2096.207/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042="
		"Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701=2295,207=1793.22,-cdn=unknown/cts=1575282403689/*\r\n/reqid=1575282401.30245.139705.388477/dtype=stred/pid=1/cid=72202/path=690.1033/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env="
		"production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,2129=1575282401666,1036=0,1037=0,1038=0,1039=0,1040=34,1040.906=34,1310.2084=0,1310.2085=1875,1310.1309=10,1310.1007=1875,2299=1,2130=1917,1041=1917,1041.906=1917,2116=0,2114=0,2131=1885,2123=1875,2770=1875,2769=0,2113=0,2112=0,2111=0,2117=0,2120=34,2119=0,1484=1,-cdn=unknown/cts=1575282403689/*\r\n/reqid="
		"1575282401.30245.139705.388477/path=690.2096.207/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701=1724,207=2186.12,-cdn=unknown/cts="
		"1575282403852/*\r\n/reqid=1575282401.30245.139705.388477/path=690.2096.2748/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,2748=yastatic.net!23!;yabs.yandex.ru!2!;avatars.mds.yandex.net!25!;"
		"mc.yandex.ru!3!;,-cdn=unknown/cts=1575282403882/*", 
		LAST);

	web_add_cookie("yabs-frequency=/4/0000000000000000/VF8zRPWu9nrji72OE23bLR1mc3WXXtroS9WuG7hoFMsOE2S0/; DOMAIN=yandex.ru");

	web_custom_request("click_2", 
		"URL=https://yandex.ru/clck/click", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://yandex.ru/", 
		"Snapshot=t13.inf", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=/reqid=1575282401.30245.139705.388477/path=690.2096.207/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701=1604.2154,207=3954.92,-cdn="
		"unknown/cts=1575282405621/*\r\n/reqid=1575282401.30245.139705.388477/path=690.2096.207/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701="
		"1604.1428,207=4376.62,-cdn=unknown/cts=1575282406043/*", 
		LAST);

	web_custom_request("click_3", 
		"URL=https://yandex.ru/clck/click", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/gif", 
		"Referer=https://yandex.ru/", 
		"Snapshot=t14.inf", 
		"EncType=text/plain;charset=UTF-8", 
		"Body=/reqid=1575282401.30245.139705.388477/path=690.2096.2877/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701=1096,207.2154=3726.42,207.1428="
		"4521.42,2877=795,2924=28.15.1604,2925=0,689.2322=1650.72,-cdn=unknown/cts=1575282406188/*\r\n/reqid=1575282401.30245.139705.388477/path=690.2096.2877/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)"
		"%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701=628,207.2154=3760.52,207.1428=4521.52,2877=761,2924=28.15.1604,2925=0,689.2322=1650.72,-cdn=unknown/cts=1575282406188/*\r\n/reqid=1575282401.30245.139705.388477/path=690.2096.2877/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20"
		"(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701=2447,207.2154=4423.52,207.1428=4521.52,2877=98,2924=28.15.1604,2925=0,689.2322=1650.72,-cdn=unknown/cts=1575282406188/*\r\n/reqid=1575282401.30245.139705.388477/path=690.2096.2877/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317,0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page="
		"plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701=2953,207.2154=4374.62,207.1428=4521.62,2877=147,2924=28.15.1604,2925=0,689.2322=1650.72,-cdn=unknown/cts=1575282406188/*\r\n/reqid=1575282401.30245.139705.388477/path=690.2096.207/slots=63208,0,99;191212,0,29;135685,0,41;192370,0,56;169317"
		",0,17;190575,0,1/vars=143=28.15.899,287=213,1961=0,1964=0,1965=1,-project=morda,-page=plain,-platform=desktop,-env=production,-version=2.2341,-blocker=,1042=Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20.NET4.0C%3B%20.NET4.0E%3B%20InfoPath.3%3B%20rv%3A11.0)%20like%20Gecko,143.2129=1575282401666,143.2112=0,143.2119=0,1701=2793,207=4826.42,2924=28.15.1604,2925=0,689.2322=1650.72,-cdn=unknown/cts=1575282406493/*", 
		LAST);

	return 0;
}